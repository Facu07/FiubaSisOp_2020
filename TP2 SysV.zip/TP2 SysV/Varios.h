#include <iostream>
#include "../Sem-sv/sv_sem.h"
#include "../Sem-sv/sv_shm.h"
#include "Coordinador.h"
#define NORTE 1
#define SUR 2
#define ESTE 3
#define OESTE 4

void imprimir_padrones() {
   	cout << 90928 << " ALVAREZ, NATALIA NAYLA" << endl;
	cout << 68180 << " BONINO, ADRIAN GUSTAVO" << endl;
	cout << 96029 << " WALTER, FACUNDO IVAN" << endl;
	cout << 105463 << " TROUCAN-JOUVE, CLEMENT"  << endl;
	cout << " " << endl;
}

